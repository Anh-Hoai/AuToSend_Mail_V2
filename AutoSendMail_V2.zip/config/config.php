<?php

define('ASSETS', '../../public');
