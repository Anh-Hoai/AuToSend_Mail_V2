<form  action="/uploadfile" method="post" enctype="multipart/form-data">
            <input type="file" name="receipt">
            <button type="submit">Upload</button>
        </form>