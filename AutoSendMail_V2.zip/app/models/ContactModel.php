<?php
namespace App\models;

use App\models\BaseModel;

class ContactModel extends BaseModel
{

}